/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package modelo;

/**
 *
 * @author Fabri
 */
/*
//Poner como comentario cuando paso a swing
import java.util.List;
public interface TareaAsignable{
    void asignarVoluntario(List<Voluntario> voluntarios);
    Voluntario getVoluntarioAsignado();
}

*/ 
